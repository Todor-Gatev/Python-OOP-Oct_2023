from unittest import TestCase, main
from project.trip import Trip


class Test(TestCase):
    def setUp(self) -> None:
        self.trip = Trip(30_000, 2, False)

    def test_default_consumption_class_attribute_is_correct(self):
        expected = {'New Zealand': 7500, 'Australia': 5700, 'Brazil': 6200, 'Bulgaria': 500}
        self.assertEqual(expected, Trip.DESTINATION_PRICES_PER_PERSON)

    def test_correct_initialization(self):
        self.assertEqual(30_000, self.trip.budget)
        self.assertEqual(2, self.trip.travelers)
        self.assertEqual(False, self.trip.is_family)
        self.assertEqual({}, self.trip.booked_destinations_paid_amounts)

    def test_traveler_setter_value_less_than_one_raise_value_error(self):
        with self.assertRaises(ValueError) as ve:
            self.trip.travelers = 0

        self.assertEqual('At least one traveler is required!', str(ve.exception))

    def test_is_family(self):
        self.trip.is_family = True

        self.assertEqual(True, self.trip.is_family)

    def test_is_family_not_enough_members(self):
        self.trip.travelers = 1
        self.trip.is_family = True

        self.assertFalse(self.trip.is_family)

    def test_book_a_trip_if_wrong_destination(self):
        res = self.trip.book_a_trip("asd")

        self.assertEqual('This destination is not in our offers, please choose a new one!', res)

    def test_book_a_trip_correctly_decrease_budget_for_family_and_set_all_attr(self):
        res = self.trip.book_a_trip("New Zealand")

        self.assertEqual(15_000, self.trip.budget)
        expected = ("Successfully booked destination New Zealand! "
                    "Your budget left is 15000.00")
        self.assertEqual(expected, res)
        expected = {"New Zealand": 15000}
        self.assertEqual(expected, self.trip.booked_destinations_paid_amounts)

    def test_book_a_trip_correctly_decrease_budget_for_none_family(self):
        self.trip.is_family = True
        self.trip.book_a_trip("New Zealand")

        self.assertEqual(16_500, self.trip.budget)

    def test_book_a_trip_if_budget_not_enough(self):
        self.trip.budget = 14_999
        res = self.trip.book_a_trip("New Zealand")

        self.assertEqual('Your budget is not enough!', res)
        self.assertEqual({}, self.trip.booked_destinations_paid_amounts)

    def test_booking_status_if_not_booked_destinations(self):
        self.assertEqual("No bookings yet. Budget: 30000.00", self.trip.booking_status())

        self.trip.booked_destinations_paid_amounts = {
            'New Zealand': 15000,
            'Bulgaria': 1000
        }

        expected = ("Booked Destination: Bulgaria\n"
                    "Paid Amount: 1000.00\n"
                    "Booked Destination: New Zealand\n"
                    "Paid Amount: 15000.00\n"
                    "Number of Travelers: 2\n"
                    "Budget Left: 30000.00")

        self.assertEqual(expected, self.trip.booking_status())


if __name__ == "__main__":
    main()
