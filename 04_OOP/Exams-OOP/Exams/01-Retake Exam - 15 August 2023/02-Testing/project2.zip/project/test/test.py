from unittest import TestCase, main
from project.trip import Trip


class Test(TestCase):
    def setUp(self) -> None:
        self.t1p = Trip(10000, 1, False)
        self.t2p = Trip(10000, 2, False)
        self.t2pf = Trip(10000, 2, True)

    def test_correct_initialization(self):
        self.assertEqual(10000, self.t2p.budget)
        self.assertEqual(2, self.t2p.travelers)
        self.assertFalse(self.t2p.is_family)
        self.assertTrue(self.t2pf.is_family)
        self.assertEqual({}, self.t2p.booked_destinations_paid_amounts)

    def test_travelers_setter(self):
        with self.assertRaises(ValueError) as ve:
            self.t1p.travelers = 0

        self.assertEqual('At least one traveler is required!', str(ve.exception))

    def test_is_family_setter(self):
        self.t1p.is_family = True

        self.assertFalse(self.t1p.is_family)

    def test_book_trip_if_not_destination(self):
        res = self.t1p.book_a_trip("asdf")
        expected = 'This destination is not in our offers, please choose a new one!'

        self.assertEqual(expected, res)

    def test_book_a_trip_if_not_budget(self):
        res = self.t2p.book_a_trip('New Zealand')
        expected = 'Your budget is not enough!'

        self.assertEqual(expected, res)

    def test_book_a_trip(self):
        res = self.t2p.book_a_trip('Bulgaria')
        expected = 'Successfully booked destination Bulgaria! Your budget left is 9000.00'

        self.assertEqual(expected, res)
        self.assertEqual({"Bulgaria": 1000}, self.t2p.booked_destinations_paid_amounts)

        res = self.t2pf.book_a_trip('Bulgaria')
        expected = 'Successfully booked destination Bulgaria! Your budget left is 9100.00'

        self.assertEqual(expected, res)
        self.assertEqual({"Bulgaria": 900}, self.t2pf.booked_destinations_paid_amounts)

    def test_booking_status_if_not_booked_destinations(self):
        res = self.t2p.booking_status()
        expected = 'No bookings yet. Budget: 10000.00'

        self.assertEqual(expected, res)

    def test_booking_status_if_booked_destinations(self):
        self.t2p.booked_destinations_paid_amounts = {"Bulgaria": 900, "New Zealand": 15000}
        res = self.t2p.booking_status()
        expected = """Booked Destination: Bulgaria
Paid Amount: 900.00
Booked Destination: New Zealand
Paid Amount: 15000.00
Number of Travelers: 2
Budget Left: 10000.00"""

        self.assertEqual(expected, res)


if __name__ == "__main__":
    main()
