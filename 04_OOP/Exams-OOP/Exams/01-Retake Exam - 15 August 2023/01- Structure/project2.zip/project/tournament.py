from project.equipment.elbow_pad import ElbowPad
from project.equipment.knee_pad import KneePad
from project.teams.indoor_team import IndoorTeam
from project.teams.outdoor_team import OutdoorTeam


class Tournament:
    VALID_EQUIPMENTS = {"KneePad": KneePad, "ElbowPad": ElbowPad}
    VALID_TEAMS = {"OutdoorTeam": OutdoorTeam, "IndoorTeam": IndoorTeam}

    def __init__(self, name: str, capacity: int):
        self.name = name
        self.capacity = capacity
        self.equipment = []  # equipment obj
        self.teams = []  # teams obj

    # region getters and setters
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if not value.isalnum():
            raise ValueError("Tournament name should contain letters and digits only!")

        self.__name = value

    # endregion

    def add_equipment(self, equipment_type: str):
        if equipment_type not in self.VALID_EQUIPMENTS:
            raise Exception("Invalid equipment type!")

        self.equipment.append(self.VALID_EQUIPMENTS[equipment_type]())

        return f"{equipment_type} was successfully added."

    def add_team(self, team_type: str, team_name: str, country: str, advantage: int):
        if team_type not in self.VALID_TEAMS:
            raise Exception("Invalid team type!")

        if self.capacity == len(self.teams):
            return "Not enough tournament capacity."

        self.teams.append(self.VALID_TEAMS[team_type](team_name, country, advantage))

        return f"{team_type} was successfully added."

    def sell_equipment(self, equipment_type: str, team_name: str):
        team = next(filter(lambda x: x.name == team_name, self.teams), None)
        equipment = [x for x in self.equipment if x.__class__.__name__ == equipment_type][-1]

        if team.budget < equipment.price:
            raise Exception("Budget is not enough!")

        team.budget -= equipment.price
        team.equipment.append(equipment)
        self.equipment.remove(equipment)

        return f"Successfully sold {equipment_type} to {team_name}."

    def remove_team(self, team_name: str):
        team = next(filter(lambda x: x.name == team_name, self.teams), None)

        if not team:
            raise Exception("No such team!")

        if team.wins:
            raise Exception(f"The team has {team.wins} wins! Removal is impossible!")

        self.teams.remove(team)

        return f"Successfully removed {team_name}."

    def increase_equipment_price(self, equipment_type: str):
        number_of_changed_equipment = 0

        for e in self.equipment:
            if e.__class__.__name__ == equipment_type:
                number_of_changed_equipment += 1
                e.increase_price()

        return f"Successfully changed {number_of_changed_equipment}pcs of equipment."

    def play(self, team_name1: str, team_name2: str):
        team1 = next(filter(lambda x: x.name == team_name1, self.teams))
        team2 = next(filter(lambda x: x.name == team_name2, self.teams))

        if not team1.__class__.__name__ == team2.__class__.__name__:
            raise Exception("Game cannot start! Team types mismatch!")

        r1 = team1.advantage + sum(p.protection for p in team1.equipment)
        r2 = team2.advantage + sum(p.protection for p in team2.equipment)

        if r1 == r2:
            return "No winner in this game."

        if r1 < r2:
            team2.win()

            return f"The winner is {team2.name}."

        team1.win()

        return f"The winner is {team1.name}."

    def get_statistics(self):
        sorted_teams = sorted(self.teams, key=lambda x: -x.wins)
        res = [f"Tournament: {self.name}",
               f"Number of Teams: {len(self.teams)}",
               "Teams:",
               *[t.get_statistics() for t in sorted_teams]
               ]

        return "\n".join(res)

# class BaseTeam(ABC):
#     def __init__(self, name: str, country: str, advantage: int, budget: float):
#         self.name = name
#         self.country = country
#         self.advantage = advantage
#         self.budget = budget
#         self.wins = 0
#         self.equipment = []
# class BaseEquipment(ABC):
#     def __init__(self, protection: int, price: float):
#         self.protection = protection
#         self.price = price
