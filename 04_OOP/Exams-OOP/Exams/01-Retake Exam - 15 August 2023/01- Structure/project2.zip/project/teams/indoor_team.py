from project.teams.base_team import BaseTeam


class IndoorTeam(BaseTeam):
    def __init__(self, name: str, country: str, advantage: int, budget: float = 500.0):
        super().__init__(name, country, advantage, budget)

    def win(self):
        self.wins += 1
        self.advantage += 145
