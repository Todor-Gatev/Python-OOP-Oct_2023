from project.bookstore import Bookstore
from unittest import TestCase, main


class Test(TestCase):
    def setUp(self) -> None:
        self.store = Bookstore(12)

    def test_correct_initialization(self):
        self.assertEqual(12, self.store.books_limit)
        self.assertEqual({}, self.store.availability_in_store_by_book_titles)
        self.assertEqual(0, self.store.total_sold_books)

    def test_books_limit_setter(self):
        with self.assertRaises(ValueError) as ve:
            self.store.books_limit = 0

        self.assertEqual("Books limit of 0 is not valid", str(ve.exception))

    def test_len(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}

        self.assertEqual(4, len(self.store))

    def test_receive_book_if_not_space(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}

        with self.assertRaises(Exception) as ex:
            self.store.receive_book("asd", 10)

        self.assertEqual("Books limit is reached. Cannot receive more books!", str(ex.exception))

    def test_receive_book_if_space_new_title(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}
        res = self.store.receive_book("asd", 7)
        expected = "7 copies of asd are available in the bookstore."

        self.assertEqual(expected, res)

    def test_receive_book_if_space_old_title(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}
        res = self.store.receive_book('c', 7)
        expected = "10 copies of c are available in the bookstore."

        self.assertEqual(expected, res)

    def test_sell_book_if_no_book(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}
        with self.assertRaises(Exception) as ex:
            self.store.sell_book("d", 3)

        self.assertEqual("Book d doesn't exist!", str(ex.exception))

    def test_sell_book_if_not_enough_qty(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}
        with self.assertRaises(Exception) as ex:
            self.store.sell_book('a', 3)

        self.assertEqual("a has not enough copies to sell. Left: 1", str(ex.exception))

    def test_sell_book_if_enough_qty(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 3}
        res = self.store.sell_book('c', 3)

        self.assertEqual("Sold 3 copies of c", res)

    def test_str(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'c': 9}
        res = self.store.sell_book('c', 3)
        expected = ("Total sold books: 3\n"
                    "Current availability: 7\n"
                    " - a: 1 copies\n"
                    " - c: 6 copies")

        self.assertEqual(expected, str(self.store))


if __name__ == "__main__":
    main()
