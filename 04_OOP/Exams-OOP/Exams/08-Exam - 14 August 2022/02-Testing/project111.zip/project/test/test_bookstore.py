from unittest import TestCase, main
from project.bookstore import Bookstore


class Test(TestCase):
    def setUp(self) -> None:
        self.store = Bookstore(11)

    def test_correct_initialization(self):
        self.assertEqual(11, self.store.books_limit)
        self.assertEqual({}, self.store.availability_in_store_by_book_titles)
        self.assertEqual(0, self.store.total_sold_books)

    def test_books_limit_setter(self):
        with self.assertRaises(ValueError) as ve:
            self.store.books_limit = 0

        self.assertEqual("Books limit of 0 is not valid", str(ve.exception))

        with self.assertRaises(ValueError) as ve:
            self.store.books_limit = -1

        self.assertEqual("Books limit of -1 is not valid", str(ve.exception))

    def test_len(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'b': 2}

        self.assertEqual(3, self.store.__len__())
        self.assertEqual(3, len(self.store))

    def test_receive_book_with_over_limits(self):
        self.store.availability_in_store_by_book_titles = {'a': 11}
        with self.assertRaises(Exception) as ex:
            self.store.receive_book('z', 1)

        self.assertEqual("Books limit is reached. Cannot receive more books!", str(ex.exception))

    def test_receive_book(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'b': 2}
        res = self.store.receive_book('z', 2)
        expected = {'a': 1, 'b': 2, 'z': 2}

        self.assertEqual(expected, self.store.availability_in_store_by_book_titles)
        self.assertEqual("2 copies of z are available in the bookstore.", res)

    def test_receive_book_with_existing(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'b': 2}
        res = self.store.receive_book('a', 2)
        expected = {'a': 3, 'b': 2}

        self.assertEqual(expected, self.store.availability_in_store_by_book_titles)
        self.assertEqual("3 copies of a are available in the bookstore.", res)

    def test_sell_book_if_not_book(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'b': 2}
        with self.assertRaises(Exception) as ex:
            self.store.sell_book('z', 1)

        self.assertEqual("Book z doesn't exist!", str(ex.exception))

    def test_sell_book_if_not_enough_books(self):
        self.store.availability_in_store_by_book_titles = {'a': 1, 'b': 2}
        with self.assertRaises(Exception) as ex:
            self.store.sell_book('a', 2)

        expected = "a has not enough copies to sell. Left: 1"
        self.assertEqual(expected, str(ex.exception))

    def test_sell_book_if_is_ok(self):
        self.store.availability_in_store_by_book_titles = {'a': 3, 'b': 0}
        res = self.store.sell_book('a', 3)
        self.assertEqual({'a': 0, 'b': 0}, self.store.availability_in_store_by_book_titles)
        self.assertEqual(3, self.store.total_sold_books)
        # self.assertEqual(1, self.store.__len__())

        expected = "Sold 3 copies of a"

        self.assertEqual(expected, res)

        # res = self.store.sell_book('a', 1)
        # self.assertEqual({'a': 0, 'b': 0}, self.store.availability_in_store_by_book_titles)
        # # self.assertEqual(3, self.store.total_sold_books)
        # # self.assertEqual(0, self.store.__len__())
        #
        # expected = "Sold 1 copies of a"
        #
        # self.assertEqual(expected, res)

    def test_str(self):
        self.store._Bookstore__total_sold_books = 3
        self.store.availability_in_store_by_book_titles = {'a': 3, 'b': 2}

        expected = ("Total sold books: 3\n"
                    "Current availability: 5\n"
                    " - a: 3 copies\n"
                    " - b: 2 copies")
        self.assertEqual(expected, str(self.store))


if __name__ == "__main__":
    main()
