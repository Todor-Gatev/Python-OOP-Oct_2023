class Controller:
    SUSTENANCE_TYPES = ["Food", "Drink"]

    def __init__(self):
        self.players = []
        self.supplies = []

    # region supporting staff
    def __get_player_via_name(self, name):
        return next(filter(lambda x: x.name == name, self.players), None)

    # endregion

    def add_player(self, *players):
        names = []

        for p in players:
            if p not in self.players:
                self.players.append(p)
                names.append(p.name)

        return f"Successfully added: {', '.join(names)}"

    def add_supply(self, *supplies):
        [self.supplies.append(s) for s in supplies]

    def sustain(self, player_name: str, sustenance_type: str):
        player = self.__get_player_via_name(player_name)

        if sustenance_type not in self.SUSTENANCE_TYPES or not player:
            return

        if not player.need_sustenance:
            return f"{player_name} have enough stamina."

        for i in range(len(self.supplies) - 1, -1, -1):
            if self.supplies[i].__class__.__name__ == sustenance_type:
                supply = self.supplies[i]
                self.supplies.pop(i)
                player.stamina = min(player.stamina + supply.energy, 100)

                return f"{player_name} sustained successfully with {supply.name}."

        raise Exception(f"There are no {sustenance_type.lower()} supplies left!")

    def duel(self, first_player_name: str, second_player_name: str):
        player1 = self.__get_player_via_name(first_player_name)
        player2 = self.__get_player_via_name(second_player_name)

        is_zero_stamina = [p for p in [player1, player2] if p.stamina == 0]

        if is_zero_stamina:
            return "\n".join(f"Player {p.name} does not have enough stamina." for p in is_zero_stamina)

        if player1.stamina < player2.stamina:
            dueler1, dueler2 = player1, player2
        else:
            dueler1, dueler2 = player2, player1

        dueler2.stamina -= dueler1.stamina / 2
        dueler1.stamina = max(dueler1.stamina - dueler2.stamina / 2, 0)

        if dueler1.stamina > dueler2.stamina:
            return f"Winner: {dueler1.name}"

        return f"Winner: {dueler2.name}"

    def next_day(self):
        for p in self.players:
            p.stamina = max(0, p.stamina - p.age * 2)
            self.sustain(p.name, "Food")
            self.sustain(p.name, "Drink")

    def __str__(self):
        return "\n".join(str(x) for x in [*self.players, *[s.details() for s in self.supplies]])

# class Player:
#     def __init__(self, name: str, age: int, stamina: int = 100):
#         self.name = name
#         self.age = age
#         self.stamina = stamina
# class Supply(ABC):
#     def __init__(self, name: str, energy: int):
#         self.name = name
#         self.energy = energy
