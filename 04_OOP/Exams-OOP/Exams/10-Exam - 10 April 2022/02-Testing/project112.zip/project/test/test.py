from project.movie import Movie
from unittest import TestCase, main


class Test(TestCase):
    def setUp(self) -> None:
        self.movie = Movie("asd", 1999, 4.5)

    def test_correct_initialization(self):
        self.assertEqual("asd", self.movie.name)
        self.assertEqual(1999, self.movie.year)
        self.assertEqual(4.5, self.movie.rating)
        self.assertEqual([], self.movie.actors)

    def test_name_setter(self):
        with self.assertRaises(ValueError) as ve:
            self.movie.name = ''

        expected = "Name cannot be an empty string!"
        self.assertEqual(expected, str(ve.exception))

    def test_year_setter(self):
        with self.assertRaises(ValueError) as ve:
            self.movie.year = 1886

        expected = "Year is not valid!"
        self.assertEqual(expected, str(ve.exception))

    def test_add_actor_if_exists(self):
        self.movie.actors = ["asddd"]
        expected = "asddd is already added in the list of actors!"

        self.assertEqual(expected, self.movie.add_actor("asddd"))

    def test_add_actor(self):
        self.movie.actors = ['a', 'b']
        self.movie.add_actor('c')

        self.assertEqual(['a', 'b', 'c'], self.movie.actors)

    def test_gt_if_better_rating(self):
        other = Movie("bbb", 1998, 4.4)
        expected = '"asd" is better than "bbb"'

        self.assertEqual(expected, self.movie.__gt__(other))

    def test_gt_if_not_better_rating(self):
        other = Movie("bbb", 1998, 4.5)
        expected = '"bbb" is better than "asd"'

        self.assertEqual(expected, self.movie.__gt__(other))

    def test_repr(self):
        self.movie.actors = ['a', 'b', 'c']
        expected = ("Name: asd\n"
                    "Year of Release: 1999\n"
                    "Rating: 4.50\n"
                    "Cast: a, b, c")

        self.assertEqual(expected, self.movie.__repr__())


if __name__ == "__main__":
    main()
