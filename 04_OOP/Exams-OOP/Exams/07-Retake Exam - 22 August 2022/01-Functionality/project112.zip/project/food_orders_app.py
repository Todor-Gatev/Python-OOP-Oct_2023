from project.client import Client
from project.meals.meal import Meal


class FoodOrdersApp:
    # MEAL_TYPES = {"Starter": Starter, "MainDish": MainDish, "Dessert": Dessert}
    MEAL_TYPES = ["Starter", "MainDish", "Dessert"]
    receipt_id = 0

    def __init__(self):
        self.menu = []
        self.clients_list = []

    def register_client(self, client_phone_number: str):
        if self.__find_client_via_phone_number(client_phone_number):
            raise Exception("The client has already been registered!")

        self.clients_list.append(Client(client_phone_number))

        return f"Client {client_phone_number} registered successfully."

    def add_meals_to_menu(self, *meals: Meal):
        for meal in meals:
            if meal.__class__.__name__ in self.MEAL_TYPES:
                self.menu.append(meal)

    def show_menu(self):
        self.__is_menu_ready()

        return "\n".join(m.details() for m in self.menu)

    def __is_menu_ready(self):
        if len(self.menu) < 5:
            raise Exception("The menu is not ready!")

    def add_meals_to_shopping_cart(self, client_phone_number: str, **meal_names_and_quantities):
        self.__is_menu_ready()

        client = self.__find_client_via_phone_number(client_phone_number)

        if not client:
            self.register_client(client_phone_number)
            client = self.__find_client_via_phone_number(client_phone_number)

        for meal_name, qty in meal_names_and_quantities.items():
            meal = next(filter(lambda m: m.name == meal_name, self.menu), None)

            if not meal:
                raise Exception(f"{meal_name} is not on the menu!")

            if meal.quantity < qty:
                raise Exception(f"Not enough quantity of {meal.__class__.__name__}: {meal_name}!")

        for meal_name, qty in meal_names_and_quantities.items():
            meal = next(filter(lambda m: m.name == meal_name, self.menu), None)
            meal.quantity -= qty
            client.shopping_cart.append(meal)
            client.bill += meal.price * qty
            client.ordered_meals[meal_name] = client.ordered_meals.get(meal_name, 0) + qty

        return (f"Client {client_phone_number} "
                f"successfully ordered {', '.join(m.name for m in client.shopping_cart)} "
                f"for {client.bill:.2f}lv.")

    def cancel_order(self, client_phone_number: str):
        client = self.__find_client_via_phone_number(client_phone_number)

        self.__is_meals_in_client_cart(client)

        for name, qty in client.ordered_meals.items():
            meal = next(filter(lambda m: m.name == name, self.menu), None)
            meal.quantity += qty

        client.shopping_cart.clear()
        client.bill = 0.0
        client.ordered_meals.clear()

        return f"Client {client_phone_number} successfully canceled his order."

    @staticmethod
    def __is_meals_in_client_cart(client):
        if not client.shopping_cart:
            raise Exception("There are no ordered meals!")

    def finish_order(self, client_phone_number: str):
        client = self.__find_client_via_phone_number(client_phone_number)
        self.__is_meals_in_client_cart(client)
        self.receipt_id += 1
        total_paid_money = client.bill
        client.bill = 0.0
        client.shopping_cart.clear()
        client.ordered_meals.clear()

        return (f"Receipt #{self.receipt_id} "
                f"with total amount of {total_paid_money:.2f} "
                f"was successfully paid for {client_phone_number}.")

    def __str__(self):
        return f"Food Orders App has {len(self.menu)} meals on the menu and {len(self.clients_list)} clients."

    def __find_client_via_phone_number(self, client_phone_number: str):
        return next(filter(lambda x: x.phone_number == client_phone_number, self.clients_list), None)

# class Client:
#     def __init__(self, phone_number: str):
#         self.phone_number = phone_number
#         self.shopping_cart = []
#         self.bill = 0.0
# class Meal(ABC):
#     def __init__(self, name: str, price: float, quantity: int):
#         self.name = name
#         self.price = price
#         self.quantity = quantity
