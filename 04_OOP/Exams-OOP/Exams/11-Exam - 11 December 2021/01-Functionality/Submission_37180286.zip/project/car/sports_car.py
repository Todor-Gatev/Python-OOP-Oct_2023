from project.car.car import Car


class SportsCar(Car):
    # region getters and setters
    @property
    def min_speed_limit(self):
        return 400

    @property
    def max_speed_limit(self):
        return 600
    # endregion
