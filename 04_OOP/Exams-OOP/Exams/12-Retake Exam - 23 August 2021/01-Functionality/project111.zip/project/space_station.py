from project.astronaut.astronaut_repository import AstronautRepository
from project.astronaut.biologist import Biologist
from project.astronaut.geodesist import Geodesist
from project.astronaut.meteorologist import Meteorologist
from project.planet.planet import Planet
from project.planet.planet_repository import PlanetRepository


class SpaceStation:
    ASTRONAUT_TYPES = {"Biologist": Biologist, "Geodesist": Geodesist, "Meteorologist": Meteorologist}

    def __init__(self):
        self.planet_repository = PlanetRepository()
        self.astronaut_repository = AstronautRepository()
        self.number_of_successful_missions = 0
        self.number_of_not_completed_missions = 0

    def add_astronaut(self, astronaut_type: str, name: str):
        if astronaut_type not in self.ASTRONAUT_TYPES:
            raise Exception("Astronaut type is not valid!")

        if self.astronaut_repository.find_by_name(name):
            return f"{name} is already added."

        self.astronaut_repository.add(self.ASTRONAUT_TYPES[astronaut_type](name))

        return f"Successfully added {astronaut_type}: {name}."

    def add_planet(self, name: str, items: str):
        if self.planet_repository.find_by_name(name):
            return f"{name} is already added."

        planet = Planet(name)
        planet.items.extend(items.split(", "))

        self.planet_repository.add(planet)

        return f"Successfully added Planet: {name}."

    def retire_astronaut(self, name: str):
        astronaut = self.astronaut_repository.find_by_name(name)
        if not astronaut:
            raise Exception(f"Astronaut {name} doesn't exist!")

        self.astronaut_repository.remove(astronaut)

        return f"Astronaut {name} was retired!"

    def recharge_oxygen(self):
        for a in self.astronaut_repository.astronauts:
            a.increase_oxygen(10)

    def send_on_mission(self, planet_name: str):
        planet = self.planet_repository.find_by_name(planet_name)

        if not planet:
            raise Exception("Invalid planet name!")

        astronauts_on_mission = sorted(self.astronaut_repository.astronauts, key=lambda x: -x.oxygen)
        astronauts_on_mission = [a for a in astronauts_on_mission if a.oxygen > 30]

        if not astronauts_on_mission:
            raise Exception("You need at least one astronaut to explore the planet!")

        astronauts_on_mission = astronauts_on_mission[:min(5, len(astronauts_on_mission))]

        i = 0

        while i < len(astronauts_on_mission) and planet.items:
            if astronauts_on_mission[i].oxygen <= 0:
                i += 1
                continue

            astronauts_on_mission[i].backpack.append(planet.items.pop())
            astronauts_on_mission[i].breathe()

        if not planet.items:
            self.number_of_successful_missions += 1

            return f"Planet: {planet_name} was explored. {i + 1} astronauts participated in collecting items."

        self.number_of_not_completed_missions += 1

        return "Mission is not completed."

    def report(self):
        res = [
            f"{self.number_of_successful_missions} successful missions!",
            f"{self.number_of_not_completed_missions} missions were not completed!",
            "Astronauts' info:",
            *[str(a) for a in self.astronaut_repository.astronauts]
        ]

        return "\n".join(res)
