from abc import ABC, abstractmethod


class Astronaut(ABC):
    def __init__(self, name: str, oxygen: int):
        self.name = name
        self.oxygen = oxygen
        self.backpack = []

    # region getters and setters
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if not value.strip():
            raise ValueError("Astronaut name cannot be empty string or whitespace!")
        self.__name = value

    # endregion

    @abstractmethod
    def breathe(self):
        ...

    def increase_oxygen(self, amount: int):
        self.oxygen += amount

    def __str__(self):
        return (f"Name: {self.name}\n"
                f"Oxygen: {self.oxygen}\n"
                f"Backpack items: "
                f'{", ".join(self.backpack) or "none"}')

        # backpack_info = ", ".join(self.backpack) or "none"
        #
        # return (f"Name: {self.name}\n"
        #         f"Oxygen: {self.oxygen}\n"
        #         f"Backpack items: {backpack_info}")
